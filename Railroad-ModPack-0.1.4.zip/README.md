# Railroad-ModPack
 A bunch of mods that the Railroad Radio crew have tested quite thoroughly and play really well together.
 We do play with a lot of cards disabled, and I wish there was a way to include that with a modpack.

 Wanted to create a modpack where I could do version control for mod updates, and only upgrade when versions are compatible. Specifically so that when I do find a working version upgrade, I don't have to walk every single person through which mods to upgrade.

## Version 0.1.4 - removing HDC and CommitmentCards adding PoppyPlaytimeCards
  The dino cards from HDC were too strong, ended up playing with all but 1 or 2 of them disabled. Just removing the whole pack.
  Likewise with commitmentcards, really liked distill and copy, but everything else was too strong.

  Adding PoppyPlaytimeCards to give it a try.

## Version 0.1.3 - removing FFC
  FFC is breaking other card packs because it uses an older version of class manager, removing it.

### Version 0.1.2 - Upgrading to versions
  Removed DullNevCards, added MadCards. Upgraded everything to most recent.

### Version 0.1.1 - First upload
  Current Mod versions are working well, Its the most stable game of rounds we have had in a long time.

  Just added the CR card pack however, and have noticed some of the CR cards can drasticaly decrease performance and cause crashes with the right pairings. But disabling the CR cards, the game will be really stable.
